package Modelo;

//Modelo del sistema
import java.math.BigInteger;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "administrador")
public class Administrador {
	
	@Id
	@Column(name = "idAdministrador")
	private int idAdministrador ;
	
	@Column(name = "Numero_Contacto", nullable = true)
	private BigInteger Numero_Contacto;
	
	@Column(name = "Direccion", nullable = true)
	private String Direccion;
	
	public Administrador() {
		
	};
	


	public int getIdAdministrador() {
		return idAdministrador;
	}





	public void setIdAdministrador(int idAdministrador) {
		this.idAdministrador = idAdministrador;
	}





	public BigInteger getNumero_Contacto() {
		return Numero_Contacto;
	}


	public void setNumeroContacto(BigInteger numeroContacto) {
		Numero_Contacto = numeroContacto;
	}


	public String getDireccion() {
		return Direccion;
	}





	public void setDireccion(String direccion) {
		Direccion = direccion;
	}





	@Override
	public String toString() {
		return "Administrador [idAdministrador=" + idAdministrador + ", Numero_Contacto=" + Numero_Contacto
				+ ", Direccion=" + Direccion + "]";
	}











	















}
